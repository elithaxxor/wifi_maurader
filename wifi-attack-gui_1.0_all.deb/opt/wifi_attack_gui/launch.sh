#!/bin/bash
echo "[*] Launching Wi-Fi Attack Toolkit backend..."
cd /opt/wifi_attack_gui/backend
uvicorn api_server:app --host 0.0.0.0 --port 8000 --reload
